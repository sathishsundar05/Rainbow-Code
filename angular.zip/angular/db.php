<?php
$conn=mysqli_connect("localhost","root","12345","employee") or die("MySQL Error: " . mysqli_error());
?>
