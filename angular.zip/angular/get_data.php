<?php
include("db.php");

if(isset($_POST['row_no']))
{
	$row=$_POST['row_no'];
	$row=$row-1;
	$sql="select * from details limit $row,10";
	$select_data=mysqli_query($conn,$sql);
	$row=mysqli_fetch_array($select_data);
	

	$query = mysqli_query($conn,$sql);
	
	if($query) 
	{
		while($row=mysqli_fetch_assoc($query))
		{
			echo $row['id'].".",$row['name']."<br>";
		}
	}
}
?>