<?php
	include('db.php');
	
	$data=json_decode(file_get_contents("php://input"));
	$id=$data->id;
	$sql="delete from details where id='$id'";
	mysqli_query($conn,$sql);
?>