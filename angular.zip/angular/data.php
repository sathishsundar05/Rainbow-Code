<?php
include('db.php');
$sql="select * from details";
$result = mysqli_query($conn, $sql);

$data= array();

while ($row = mysqli_fetch_object($result)) {
  $data[] = $row;
}
    echo   json_encode($data);
?>