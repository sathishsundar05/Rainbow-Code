<?php
	include('db.php');
	
	$data=json_decode(file_get_contents("php://input"));
	$id=$data->id;
	$name=$data->name;
	$email=$data->email;
	$sql="update details set name='$name', email='$email' where id='$id'";
	mysqli_query($conn,$sql);
?>
