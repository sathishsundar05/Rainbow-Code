<?php
	include('db.php');
	$data=json_decode(file_get_contents("php://input"));

	$name=$data->name;
	$email=$data->email;
	$sql="INSERT INTO details(name,email) VALUES('$name','$email')";
	$query=mysqli_query($conn,$sql);
	if($query)
	{
		echo "success";
	}
	else
	{
		echo "fail";
	}
?>