var app=angular.module("myapp",[]);

app.controller("getdata",function($scope,$http,$rootScope)
{
	$rootScope.$on("updateData", function()
	{
           $scope.updateData();
        });
	
	$scope.updateData = function()
	{
		$http.get("data.php").then(function(response)
		{
			$scope.users=response.data;
		})
	}
	$scope.updateData();
	
	$scope.user_edit=function(id,name,email)
	{
		$scope.id=id;
		$scope.name=name;
		$scope.email=email;
	}
	$scope.update_data=function()
	{
		$http.post("update.php",{'id':$scope.id,'name':$scope.name,'email':$scope.email}).then(function(response)
		{
			Materialize.toast('Employee Details Updated Successfully', 2000);
			$scope.updateData();
			$("#modal2").modal("close");
		})
	}
	$scope.delete_user=function(id,name,email)
	{
		$scope.delete_id=id;
	}
	$scope.delete_yes=function()
	{
		$http.post("delete.php",{'id':$scope.delete_id}).then(function(response)
		{
			Materialize.toast('Employee Deleted Successfully', 2000);
			$scope.updateData();
		})
	}
});
app.controller("insertdata",function($scope,$http,$rootScope)
{
	$scope.insertdata=function()
	{
		$http.post("insert.php",{'name':$scope.name,'email':$scope.email}).then(function(response)
		{
			Materialize.toast('Employee Added Successfully', 2000)
			$rootScope.$emit("updateData",{});
			$scope.updateData();
		})
	}
});
$(document).ready(function()
{
	$('.cntct_form').addClass("scale-out");
	$('.button-collapse').sideNav();
	$('.cntct_add').click(function()
	{
		$('.cntct_form').removeClass("scale-out");
		$('.cntct_form').addClass("scale-in");
	});
	
	$(".page_no").click(function()
	{
		var no=$(this).attr("id");
		$('.responsive-table').addClass("opacity");
		$('.preloader-wrapper').addClass("active");
		setTimeout(function()
		{
			$('.responsive-table').removeClass("opacity");
			$('.preloader-wrapper').removeClass("active");
			get_data(no);
		},1000);
	});
	function get_data(no)
	{
		$.ajax
		({
			type:'post',
			url:'data.php',
			data:{page:no},
			success:function(response) 
			{
				$(".collection>table>tbody").html(response);
			}
		});
	}
	/*$('.add_emp').click(function(e)
	{
		e.preventDefault();
		
		var a=$('#name').val();
		var b=$('#email').val();

		$('.responsive-table').addClass("opacity");
		$('.preloader-wrapper').addClass("active");
		setTimeout(function()
		{
			$('.responsive-table').removeClass("opacity");
			$('.preloader-wrapper').removeClass("active");
		},1000);

		$('#name').val("");
		$('#email').val("");
		$(":radio").prop("checked", false);

		$('.cntct_form').removeClass("scale-in");
		$('.cntct_form').addClass("scale-out");

	});
	*/
	$('.modal').modal();
});
