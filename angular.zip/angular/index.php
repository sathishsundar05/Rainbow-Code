<!DOCTYPE html>
<html>
	<link rel="stylesheet" href="materialise.min.css">
	<link rel="stylesheet" href="custom.css">
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
	
	<script src="angular.min.js"></script>
	<script src="angular-route.min.js"></script>
	<script src="jquery.min.js"></script>
	<script src="materialise.min.js"></script>
	<script src="custom.js"></script>
	<head>
		<style>
			.preloader-wrapper
			{
				position: absolute;
				z-index: 1000;
				top: 50%;
				left: 45%;
			}
			.opacity
			{
				opacity:0.5;
			}
			.pagination>li
			{
				margin-left: 10px;
				margin-right: 10px;
			}
		</style>
	</head>

	<body ng-app="myapp">
		<div class="main">
			<nav class="deep-orange" role="navigation">
				<div class="nav-wrapper container"><a id="logo-container" href="" class="brand-logo">Employee Management Panel</a>
					<ul class="right hide-on-med-and-down">
						<li><a href="#modal1">Login</a></li>
					</ul>

					<ul id="nav-mobile" class="side-nav">
						<li><a href="#modal1">Login</a></li>
					</ul>
					<a href="#" data-activates="nav-mobile" class="button-collapse"><i class="material-icons">menu</i></a>
				</div>
			</nav>
			<div class="container">
				<div class="row">
					<div class="collection col l8 m6 s12" ng-controller="getdata">
						<table class="centered responsive-table">
							<thead>
								<tr>
									<th>Employee ID</th>
									<th>Employee Name</th>
									<th>Employee Email</th>
									<th>Edit</th>
									<th>Delete</th>
								</tr>
							</thead>
							<tbody>
								<tr ng-repeat="details in users">
									<td>{{details.id}}</td>
									<td>{{details.name}}</td>
									<td>{{details.email}}</td>
									<td>
										<a href="#modal2"><i class="material-icons" ng-click="user_edit(details.id,details.name,details.email)">mode_edit</i></a>
									</td>
									<td>
										<a href="#delete_modal"><i class="material-icons" ng-click="delete_user(details.id,details.name,details.email)">delete</i></a>
									</td>
								</tr>
							</tbody>
						</table>
						<div class="modal" id="modal2">
							<div class="modal-content">
								<div class="row">
									<div class="input-field">
										<h4>Update Employee Details</h4>
										<i class="material-icons prefix">account_circle</i>
										<input type="text" ng-model="name"><br>
										<i class="material-icons prefix">email</i>
										<input type="text" ng-model="email">
									</div>
								</div>
								<div class="row right">
									<a href="#" class="waves-effect waves-light btn upd_emp deep-orange" ng-click="update_data(id,name,email)">Update Details</a>
								</div>
							</div>
						</div>
						<div class="modal" id="delete_modal">
							<div class="modal-content">
								<div class="row">
									<h4>Are You Sure You Want To Delete</h4>
								</div>
							</div>
							<div class="modal-footer">
								<a href="#" class="modal-action modal-close waves-effect waves-green btn-flat">No</a>
								<a class="modal-action modal-close waves-effect waves-green btn-flat" ng-click="delete_yes()">Yes</a>
							</div>
						</div>
						
						<!--<div class="pagination" style="margin-bottom: 10px">
							<li class="disabled"><a href="#!"><i class="material-icons">chevron_left</i></a></li>
							//<?php
								//include("db.php");
								//$limit=8;
								//$sql = "SELECT COUNT(id) FROM details";  
								//$result=mysqli_query($conn,$sql);
								//$row = mysqli_fetch_row($result);  
								//$total_records = $row[0]; 
								//$total_pages = ceil($total_records / $limit);
								//for($i=1;$i<=$total_pages;$i++)
								//{
									//$pagelinks="<li class='waves-effect'><a class='btn page_no white-text deep-orange' id='".$i."'>".$i."</a></li>";
									//echo $pagelinks;
								//};
							//?>
							<li class="waves-effect"><a href="#!"><i class="material-icons">chevron_right</i></a></li>
						</div>-->
						<div class="preloader-wrapper small">
							<div class="spinner-layer spinner-green-only">
								<div class="circle-clipper left">
									<div class="circle"></div>
								</div>
								<div class="gap-patch">
									<div class="circle"></div>
								</div>
								<div class="circle-clipper right">
									<div class="circle"></div>
								</div>
							</div>
						</div>
					</div>
					<div class="col l4 m6 s12" style="padding-left: 10px" ng-controller="insertdata">
						<div class="card blue-grey darken-1">
							<div class="card-content white-text">
								<span class="card-title" style="margin-bottom:0">Add Employee</span>
								<a class="btn-floating halfway-fab waves-effect waves-light red cntct_add"><i class="material-icons">add</i></a>
							</div>
						</div>
						<div class="cntct_form scale-transition" style="padding-top: 15px">
							<div class="row">
								<div class="s12 input-field">
									<i class="material-icons prefix">account_circle</i>
									<input type="text" class="validate" id="name" ng-model="name">
									<label for="name">Employee Name</label>
								</div>
							</div>
							<div class="row">
								<div class="s12 input-field">
									<i class="material-icons prefix">email</i>
									<input type="email" class="validate" id="email" ng-model="email">
									<label for="email">Employee email</label>
								</div>
							</div>
							<div class="row">
								<div class="input-field" style="padding-left: 35px;">
									<p>
										<input type="radio" id="male" class="with-gap radio" name="group1">
										<label for="male">Male</label>
									</p>
									<p>
										<input type="radio" id="female" class="with-gap radio" name="group1">
										<label for="female">Female</label>
									</p>
								</div>
							</div>
							<div class="row right">
								<a class="waves-effect waves-light btn add_emp deep-orange" ng-click="insertdata()">Add Employee</a>
							</div>
						</div>
					</div>
				</div>
				<div class="modal" id="modal1">
					<div class="modal-content">
						<h4>Login</h4>
					</div>
				</div>
			</div>
		</div>
		<ng-view></ng-view>
		<footer class="page-footer" style="background-color:#FFF;border-top:1px solid #c5c5c5">
			<div class="footer-copyright">
				<div class="container black-text">
					&copy demo materialise
					<a href="#/test" class="right black-text">
						Sathish
					</a>
				</div>
			</div>
		</footer>
	</body>
</html>