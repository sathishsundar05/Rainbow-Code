 <?php
	include('db.php');

	if (isset($_GET["page"])) 
	{
		$page  = $_GET["page"]; 
	} 
	else 
	{
		$page=1; 
	}
	$start_from = ($page-1) * $limit; 
	
	$sql="SELECT * FROM demo_table LIMIT $start_from, $limit";

	$query = mysqli_query($conn,$sql);
	
	if($query) 
	{
		while($row=mysqli_fetch_assoc($query))
		{
			echo $row['id'].".",$row['name']."<br>";
		}
	}
	else
	{
		echo "database connection error";
	}
	$sql = "SELECT COUNT(id) FROM demo_table";  
		$result=mysqli_query($conn,$sql);
		$row = mysqli_fetch_row($result);  
		$total_records = $row[0]; 
		$total_pages = ceil($total_records / $limit);
		for($i=1;$i<=$total_pages;$i++)
		{
			$pagelinks="<a href='test.php?page=".$i."'>".$i."</a>";
			echo $pagelinks;
		};
?>
